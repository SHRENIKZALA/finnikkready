import * as React from 'react'

import { cn } from '#/lib/utils.ts'

function Input({
  className,
  type,
  variant = 'default',
  ...props
}: React.ComponentProps<'input'> & {
  variant?: 'default' | 'grid'
}) {
  return (
    <input
      type={type}
      data-slot="input"
      className={cn(
        'h-7 w-full min-w-0 rounded-md border border-input bg-input/20 px-2 py-0.5 text-sm transition-colors duration-(--duration-fast) outline-none file:inline-flex file:h-6 file:border-0 file:bg-transparent file:text-xs/relaxed file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/30 disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-2 aria-invalid:ring-destructive/20 md:text-xs/relaxed dark:bg-input/30 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40',
        variant === 'grid' &&
          'h-9 rounded-none border-0 bg-transparent px-2 py-0 text-sm shadow-none dark:bg-transparent focus-visible:border-0 focus-visible:ring-0',
        className,
      )}
      {...props}
    />
  )
}

export { Input }
