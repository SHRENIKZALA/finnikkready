import * as React from 'react'
import { cva  } from 'class-variance-authority'
import type {VariantProps} from 'class-variance-authority';
import { Slot } from 'radix-ui'

import { cn } from '#/lib/utils.ts'

const badgeVariants = cva(
  'group/badge inline-flex h-5 w-fit shrink-0 items-center justify-center gap-1 overflow-hidden rounded-full border border-transparent px-2 py-0.5 text-[0.625rem] font-medium whitespace-nowrap transition-all focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 aria-invalid:border-destructive aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 [&>svg]:pointer-events-none [&>svg]:size-2.5!',
  {
    variants: {
      variant: {
        default: 'bg-primary text-primary-foreground [a]:hover:bg-primary/80',
        secondary:
          'bg-secondary text-secondary-foreground [a]:hover:bg-secondary/80',
        success: 'bg-success text-success-foreground [a]:hover:bg-success/80',
        warning: 'bg-warning text-warning-foreground [a]:hover:bg-warning/80',
        info: 'bg-info text-info-foreground [a]:hover:bg-info/80',
        'money-in':
          'bg-money-in/15 text-money-in [a]:hover:bg-money-in/25 dark:bg-money-in/20',
        'money-out':
          'bg-money-out/15 text-money-out [a]:hover:bg-money-out/25 dark:bg-money-out/20',
        gst: 'bg-gst/15 text-gst [a]:hover:bg-gst/25 dark:bg-gst/20',
        inventory:
          'bg-inventory/15 text-inventory [a]:hover:bg-inventory/25 dark:bg-inventory/20',
        banking:
          'bg-banking/15 text-banking [a]:hover:bg-banking/25 dark:bg-banking/20',
        neutral:
          'bg-secondary text-secondary-foreground [a]:hover:bg-secondary/80',
        destructive:
          'bg-destructive/10 text-destructive focus-visible:ring-destructive/20 dark:bg-destructive/20 dark:focus-visible:ring-destructive/40 [a]:hover:bg-destructive/20',
        outline:
          'border-border bg-input/20 text-foreground dark:bg-input/30 [a]:hover:bg-muted [a]:hover:text-muted-foreground',
        ghost:
          'hover:bg-muted hover:text-muted-foreground dark:hover:bg-muted/50',
        link: 'text-primary underline-offset-4 hover:underline',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  },
)

function Badge({
  className,
  variant = 'default',
  asChild = false,
  ...props
}: React.ComponentProps<'span'> &
  VariantProps<typeof badgeVariants> & { asChild?: boolean }) {
  const Comp = asChild ? Slot.Root : 'span'

  return (
    <Comp
      data-slot="badge"
      data-variant={variant}
      className={cn(badgeVariants({ variant }), className)}
      {...props}
    />
  )
}

export { Badge, badgeVariants }
